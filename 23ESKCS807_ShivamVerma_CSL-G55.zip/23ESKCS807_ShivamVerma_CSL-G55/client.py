"""
client.py - Client for the encrypted file-transfer server.
Author: Shivam Verma | 23ESKCS807 | CSL-G55

  python client.py --host 127.0.0.1 --port 5001 list
  python client.py upload  myfile.zip
  python client.py download myfile.zip --out ./downloads
Interrupted transfers resume automatically when the same command is re-run.
"""
import argparse
import getpass
import json
import os
import socket
import sys

from common import (CHUNK, T_DATA, Progress, ProtocolError, SecurityError,
                    client_handshake, file_sha256, human)


class SimulatedDrop(Exception):
    """Used by --fail-after to demonstrate resume."""


def connect(host, port, password, timeout=30):
    sock = socket.create_connection((host, port), timeout=timeout)
    try:
        return sock, client_handshake(sock, password)
    except Exception:
        sock.close()
        raise


def list_files(ch):
    ch.send_json({"cmd": "list"})
    r = ch.recv_json()
    if not r.get("ok"):
        raise ProtocolError(r.get("error"))
    return r["files"]


def upload(ch, path, show_progress=True, fail_after=None):
    name, size = os.path.basename(path), os.path.getsize(path)
    sha = file_sha256(path)
    ch.send_json({"cmd": "upload", "name": name, "size": size, "sha256": sha})
    r = ch.recv_json()
    if not r.get("ok"):
        raise ProtocolError(r.get("error"))
    offset = r["offset"]
    if offset:
        print(f"Resuming '{name}' from {human(offset)}", file=sys.stderr)
    prog = Progress(size, "upload " + name, offset, show_progress)
    sent = offset
    with open(path, "rb") as f:
        f.seek(offset)
        while sent < size:
            chunk = f.read(min(CHUNK, size - sent))
            ch.send(T_DATA, chunk)
            sent += len(chunk)
            prog.update(len(chunk))
            if fail_after is not None and sent - offset >= fail_after and sent < size:
                raise SimulatedDrop(f"simulated connection drop after {human(sent)}")
    prog.close()
    r = ch.recv_json()
    if not r.get("ok"):
        raise ProtocolError(r.get("error"))
    return r


def download(ch, name, out_dir=".", show_progress=True):
    os.makedirs(out_dir, exist_ok=True)
    final = os.path.join(out_dir, name)
    part, meta = final + ".part", final + ".part.meta"
    offset = os.path.getsize(part) if os.path.exists(part) else 0
    ch.send_json({"cmd": "download", "name": name, "offset": offset})
    r = ch.recv_json()
    if not r.get("ok"):
        raise ProtocolError(r.get("error"))
    size, sha, offset = r["size"], r["sha256"], r["offset"]
    # discard a stale partial file that belongs to a different version of the file
    old = {}
    if os.path.exists(meta):
        try:
            with open(meta) as mf:
                old = json.load(mf)
        except Exception:
            pass
    if offset and old.get("sha256") != sha:
        # server already accepted our offset; we must restart cleanly
        os.remove(part)
        raise ProtocolError("stale partial file removed; run the command again")
    with open(meta, "w") as f:
        json.dump({"sha256": sha, "size": size}, f)
    if offset:
        print(f"Resuming '{name}' from {human(offset)}", file=sys.stderr)
    prog = Progress(size, "download " + name, offset, show_progress)
    got = offset
    with open(part, "ab" if offset else "wb") as f:
        while got < size:
            t, p = ch.recv()
            if t != T_DATA or got + len(p) > size:
                raise ProtocolError("unexpected frame during download")
            f.write(p)
            got += len(p)
            prog.update(len(p))
    prog.close()
    if file_sha256(part) != sha:
        os.remove(part)
        os.remove(meta)
        raise SecurityError("SHA-256 mismatch - downloaded file discarded")
    os.replace(part, final)
    os.remove(meta)
    return final


def main():
    ap = argparse.ArgumentParser(description="Encrypted file transfer client")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5001)
    ap.add_argument("--password", default=os.environ.get("FT_PASSWORD"))
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    u = sub.add_parser("upload")
    u.add_argument("file")
    u.add_argument("--fail-after", type=int, metavar="BYTES",
                   help="demo: abort after BYTES to test resume")
    d = sub.add_parser("download")
    d.add_argument("name")
    d.add_argument("--out", default="./downloads")
    a = ap.parse_args()

    pw = a.password or getpass.getpass("Shared password: ")
    try:
        sock, ch = connect(a.host, a.port, pw)
    except SecurityError as e:
        sys.exit(f"[!] {e}")
    except OSError as e:
        sys.exit(f"[!] cannot connect: {e}")
    try:
        if a.cmd == "list":
            files = list_files(ch)
            print(f"{'NAME':<40} SIZE")
            for f in files:
                print(f"{f['name']:<40} {human(f['size'])}")
            if not files:
                print("(no files)")
        elif a.cmd == "upload":
            print("[+]", upload(ch, a.file, fail_after=a.fail_after).get("msg"))
        elif a.cmd == "download":
            print("[+] saved to", download(ch, a.name, a.out))
        ch.send_json({"cmd": "quit"})
    except SimulatedDrop as e:
        sock.close()
        sys.exit(f"\n[!] {e} - run the same command again to resume")
    except (ProtocolError, SecurityError, ConnectionError, OSError) as e:
        sys.exit(f"\n[!] {e}")
    finally:
        sock.close()


if __name__ == "__main__":
    main()
