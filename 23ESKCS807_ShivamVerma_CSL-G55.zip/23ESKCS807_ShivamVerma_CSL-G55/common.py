"""
common.py - Shared crypto channel, handshake and helpers.
Project : Multi-client Encrypted File Transfer with HMAC (Secure LAN File Transfer)
Author  : Shivam Verma | Roll No: 23ESKCS807 | Project Code: CSL-G55

Security design (Encrypt-then-MAC):
  * Key derivation : PBKDF2-HMAC-SHA256(password, per-connection salt)
                     -> session keys derived with HMAC-SHA256 using both nonces
                     (separate AES key and HMAC key).
  * Confidentiality: AES-256 in CTR mode, fresh random 16-byte IV for every frame.
  * Integrity      : HMAC-SHA256 over (direction | sequence no. | IV | ciphertext).
                     The tag is verified BEFORE decryption; compare_digest is used.
  * Anti-replay    : 64-bit sequence number is inside the MAC, per direction.
  * Authentication : mutual challenge-response proofs (HMAC) after key derivation,
                     so a wrong password is rejected without sending the password.
  * End-to-end     : SHA-256 of the whole file is checked after every transfer.
"""
import hashlib
import hmac
import json
import os
import struct
import sys
import time

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

CHUNK = 64 * 1024                  # data bytes per frame
IV_LEN = 16
TAG_LEN = 32
MAX_FRAME = CHUNK + 1024 + IV_LEN + TAG_LEN
PBKDF2_ITERS = 200_000

T_JSON = b"J"                      # control message
T_DATA = b"D"                      # file data chunk


class SecurityError(Exception):
    """MAC failure, replay, bad handshake, wrong password..."""


class ProtocolError(Exception):
    """Malformed or unexpected message."""


# ------------------------------------------------------------------ helpers
def recv_exact(sock, n):
    buf = bytearray()
    while len(buf) < n:
        part = sock.recv(n - len(buf))
        if not part:
            raise ConnectionError("connection closed by peer")
        buf += part
    return bytes(buf)


def file_sha256(path, bufsize=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(bufsize)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def human(n):
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.2f} {unit}"
        n /= 1024


class Progress:
    """Console progress bar with speed and ETA. `start` = already-done bytes (resume)."""

    def __init__(self, total, label="", start=0, enabled=True, width=28):
        self.total, self.label, self.done = total, label, start
        self.start_done, self.enabled, self.width = start, enabled, width
        self.t0 = time.time()
        self.last = 0.0
        if enabled:
            self._draw()

    def update(self, n):
        self.done += n
        now = time.time()
        if self.enabled and (now - self.last > 0.1 or self.done >= self.total):
            self.last = now
            self._draw()

    def _draw(self):
        frac = 1.0 if self.total == 0 else min(self.done / self.total, 1.0)
        filled = int(self.width * frac)
        bar = "#" * filled + "-" * (self.width - filled)
        el = max(time.time() - self.t0, 1e-6)
        speed = (self.done - self.start_done) / el
        eta = (self.total - self.done) / speed if speed > 0 else 0
        sys.stderr.write(
            f"\r{self.label[:22]:<22} [{bar}] {frac*100:6.2f}% "
            f"{human(self.done)}/{human(self.total)} {human(speed)}/s ETA {eta:4.0f}s  ")
        sys.stderr.flush()

    def close(self):
        if self.enabled:
            self._draw()
            sys.stderr.write("\n")


# ----------------------------------------------------------- secure channel
class SecureChannel:
    """Framed, AES-CTR encrypted, HMAC-authenticated channel over a socket."""

    def __init__(self, sock, enc_key, mac_key, role):
        assert role in ("C", "S")
        self.sock, self.enc_key, self.mac_key = sock, enc_key, mac_key
        self.send_dir = role.encode()
        self.recv_dir = (b"S" if role == "C" else b"C")
        self.send_seq = 0
        self.recv_seq = 0

    def _tag(self, direction, seq, iv, ct):
        return hmac.new(self.mac_key, direction + struct.pack(">Q", seq) + iv + ct,
                        hashlib.sha256).digest()

    def send(self, ftype, payload=b""):
        iv = os.urandom(IV_LEN)
        enc = Cipher(algorithms.AES(self.enc_key), modes.CTR(iv)).encryptor()
        ct = enc.update(ftype + payload) + enc.finalize()
        tag = self._tag(self.send_dir, self.send_seq, iv, ct)
        self.send_seq += 1
        frame = iv + ct + tag
        self.sock.sendall(struct.pack(">I", len(frame)) + frame)

    def recv(self):
        (length,) = struct.unpack(">I", recv_exact(self.sock, 4))
        if length < IV_LEN + 1 + TAG_LEN or length > MAX_FRAME:
            raise ProtocolError(f"bad frame length {length}")
        frame = recv_exact(self.sock, length)
        iv, ct, tag = frame[:IV_LEN], frame[IV_LEN:-TAG_LEN], frame[-TAG_LEN:]
        expected = self._tag(self.recv_dir, self.recv_seq, iv, ct)
        if not hmac.compare_digest(tag, expected):          # verify BEFORE decrypt
            raise SecurityError("HMAC verification failed (tampered / replayed / reordered frame)")
        self.recv_seq += 1
        dec = Cipher(algorithms.AES(self.enc_key), modes.CTR(iv)).decryptor()
        pt = dec.update(ct) + dec.finalize()
        return pt[:1], pt[1:]

    def send_json(self, obj):
        self.send(T_JSON, json.dumps(obj).encode())

    def recv_json(self):
        t, p = self.recv()
        if t != T_JSON:
            raise ProtocolError("expected control message")
        return json.loads(p.decode())


# ---------------------------------------------------------------- handshake
def _derive(password, salt, cn, sn):
    master = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERS, 32)
    enc = hmac.new(master, b"enc" + cn + sn, hashlib.sha256).digest()   # 32 bytes -> AES-256
    mac = hmac.new(master, b"mac" + cn + sn, hashlib.sha256).digest()
    return enc, mac


def client_handshake(sock, password):
    cn = os.urandom(16)
    sock.sendall(cn)
    blob = recv_exact(sock, 32)
    salt, sn = blob[:16], blob[16:]
    enc, mac = _derive(password, salt, cn, sn)
    sock.sendall(hmac.new(mac, b"client-auth" + cn + sn, hashlib.sha256).digest())
    try:
        proof = recv_exact(sock, 32)
    except ConnectionError:
        raise SecurityError("authentication failed (wrong password?)")
    if not hmac.compare_digest(proof, hmac.new(mac, b"server-auth" + cn + sn, hashlib.sha256).digest()):
        raise SecurityError("server authentication failed")
    return SecureChannel(sock, enc, mac, "C")


def server_handshake(sock, password):
    cn = recv_exact(sock, 16)
    salt, sn = os.urandom(16), os.urandom(16)
    sock.sendall(salt + sn)
    enc, mac = _derive(password, salt, cn, sn)
    proof = recv_exact(sock, 32)
    if not hmac.compare_digest(proof, hmac.new(mac, b"client-auth" + cn + sn, hashlib.sha256).digest()):
        raise SecurityError("client authentication failed (wrong password)")
    sock.sendall(hmac.new(mac, b"server-auth" + cn + sn, hashlib.sha256).digest())
    return SecureChannel(sock, enc, mac, "S")
