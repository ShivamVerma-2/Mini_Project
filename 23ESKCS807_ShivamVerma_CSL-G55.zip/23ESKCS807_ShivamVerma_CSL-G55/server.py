"""
server.py - Multi-threaded encrypted file-transfer server.
Author: Shivam Verma | 23ESKCS807 | CSL-G55

Run:  python server.py --port 5001 --storage ./server_storage
"""
import argparse
import getpass
import json
import logging
import os
import re
import socket
import threading

from common import (CHUNK, T_DATA, ProtocolError, SecurityError, file_sha256,
                    server_handshake)

log = logging.getLogger("server")
HEX64 = re.compile(r"^[0-9a-f]{64}$")


def safe_name(name):
    """Strip any path and reject hidden / odd names (prevents path traversal)."""
    if not isinstance(name, str):
        raise ProtocolError("bad file name")
    name = os.path.basename(name.replace("\\", "/"))
    name = re.sub(r"[^\w.\- ()]", "_", name)
    if not name or name.startswith(".") or len(name) > 200:
        raise ProtocolError("invalid file name")
    return name


class FileServer:
    def __init__(self, host, port, password, storage, max_clients=50,
                 max_size=4 * 1024 ** 3, idle_timeout=120):
        self.host, self.port, self.password = host, port, password
        self.storage = os.path.abspath(storage)
        self.partial = os.path.join(self.storage, ".partial")
        os.makedirs(self.partial, exist_ok=True)
        self.max_size, self.idle_timeout = max_size, idle_timeout
        self.slots = threading.BoundedSemaphore(max_clients)
        self._busy, self._busy_lock = set(), threading.Lock()
        self.sock, self._stop = None, False

    # ------------------------------------------------------------ lifecycle
    def bind(self):
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))
        self.sock.listen(64)
        self.port = self.sock.getsockname()[1]
        log.info("listening on %s:%d, storage=%s", self.host, self.port, self.storage)

    def serve_forever(self):
        if not self.sock:
            self.bind()
        while not self._stop:
            try:
                conn, addr = self.sock.accept()
            except OSError:
                break
            if not self.slots.acquire(blocking=False):
                log.warning("max clients reached, rejecting %s", addr)
                conn.close()
                continue
            threading.Thread(target=self._client_thread, args=(conn, addr),
                             daemon=True, name=f"client-{addr[0]}:{addr[1]}").start()

    def shutdown(self):
        self._stop = True
        if self.sock:
            self.sock.close()

    # ------------------------------------------------------- per client
    def _client_thread(self, conn, addr):
        try:
            conn.settimeout(self.idle_timeout)
            ch = server_handshake(conn, self.password)
            log.info("%s authenticated", addr)
            while True:
                try:
                    req = ch.recv_json()
                except ConnectionError:
                    break
                cmd = req.get("cmd")
                if cmd == "list":
                    self._list(ch)
                elif cmd == "upload":
                    self._upload(ch, req, addr)
                elif cmd == "download":
                    self._download(ch, req, addr)
                elif cmd == "quit":
                    break
                else:
                    ch.send_json({"ok": False, "error": "unknown command"})
        except SecurityError as e:
            log.warning("%s SECURITY: %s", addr, e)
        except (ProtocolError, ConnectionError, socket.timeout, ValueError) as e:
            log.warning("%s dropped: %s", addr, e)
        except Exception:
            log.exception("%s unexpected error", addr)
        finally:
            conn.close()
            self.slots.release()
            log.info("%s disconnected", addr)

    def _acquire(self, name):
        with self._busy_lock:
            if name in self._busy:
                return False
            self._busy.add(name)
            return True

    def _release(self, name):
        with self._busy_lock:
            self._busy.discard(name)

    # ------------------------------------------------------------ commands
    def _list(self, ch):
        files = []
        for n in sorted(os.listdir(self.storage)):
            p = os.path.join(self.storage, n)
            if os.path.isfile(p):
                files.append({"name": n, "size": os.path.getsize(p)})
        ch.send_json({"ok": True, "files": files})

    def _upload(self, ch, req, addr):
        try:
            name = safe_name(req.get("name"))
            size = int(req.get("size"))
            sha = str(req.get("sha256", "")).lower()
            if not (0 <= size <= self.max_size) or not HEX64.match(sha):
                raise ProtocolError("bad size/hash")
        except (ProtocolError, TypeError, ValueError) as e:
            ch.send_json({"ok": False, "error": str(e)})
            return
        if not self._acquire(name):
            ch.send_json({"ok": False, "error": "file is being transferred by another client"})
            return
        try:
            part = os.path.join(self.partial, name + ".part")
            meta = part + ".meta"
            offset = 0
            if os.path.exists(part) and os.path.exists(meta):     # resume support
                try:
                    with open(meta) as f:
                        m = json.load(f)
                except Exception:
                    m = {}
                if m.get("sha256") == sha and m.get("size") == size:
                    offset = os.path.getsize(part)
                    if offset > size:
                        offset = 0
            if offset == 0:
                with open(meta, "w") as f:
                    json.dump({"sha256": sha, "size": size}, f)
                open(part, "wb").close()
            log.info("%s upload '%s' size=%d resume_from=%d", addr, name, size, offset)
            ch.send_json({"ok": True, "offset": offset})

            received = offset
            with open(part, "ab") as f:
                while received < size:
                    t, p = ch.recv()
                    if t != T_DATA or received + len(p) > size:
                        raise ProtocolError("unexpected frame during upload")
                    f.write(p)
                    received += len(p)
                f.flush()
            if file_sha256(part) != sha:
                os.remove(part)
                os.remove(meta)
                ch.send_json({"ok": False, "error": "SHA-256 mismatch, upload discarded"})
                log.warning("%s upload '%s' hash mismatch", addr, name)
                return
            os.replace(part, os.path.join(self.storage, name))
            os.remove(meta)
            ch.send_json({"ok": True, "msg": "stored", "sha256": sha})
            log.info("%s upload '%s' complete", addr, name)
        finally:
            self._release(name)

    def _download(self, ch, req, addr):
        try:
            name = safe_name(req.get("name"))
            offset = int(req.get("offset", 0))
        except (ProtocolError, TypeError, ValueError) as e:
            ch.send_json({"ok": False, "error": str(e)})
            return
        path = os.path.join(self.storage, name)
        if not os.path.isfile(path):
            ch.send_json({"ok": False, "error": "file not found"})
            return
        size = os.path.getsize(path)
        if not 0 <= offset <= size:
            offset = 0
        ch.send_json({"ok": True, "size": size, "sha256": file_sha256(path), "offset": offset})
        log.info("%s download '%s' from %d", addr, name, offset)
        with open(path, "rb") as f:
            f.seek(offset)
            sent = offset
            while sent < size:
                chunk = f.read(min(CHUNK, size - sent))
                ch.send(T_DATA, chunk)
                sent += len(chunk)
        log.info("%s download '%s' complete", addr, name)


def main():
    ap = argparse.ArgumentParser(description="Multi-client encrypted file transfer server")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=5001)
    ap.add_argument("--storage", default="./server_storage")
    ap.add_argument("--password", default=os.environ.get("FT_PASSWORD"),
                    help="shared secret (or env FT_PASSWORD, or prompted)")
    ap.add_argument("--max-clients", type=int, default=50)
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(threadName)s] %(message)s")
    pw = args.password or getpass.getpass("Shared password: ")
    srv = FileServer(args.host, args.port, pw, args.storage, args.max_clients)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log.info("shutting down")
        srv.shutdown()


if __name__ == "__main__":
    main()
