"""Automated tests:  python -m unittest discover -s tests -v   (run from project root)"""
import json
import os
import socket
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import client
from common import SecurityError, client_handshake, file_sha256, server_handshake
from server import FileServer

PW = "test-secret"


class Env(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = os.path.join(self.tmp.name, "store")
        self.srv = FileServer("127.0.0.1", 0, PW, self.store, idle_timeout=10)
        self.srv.bind()
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def tearDown(self):
        self.srv.shutdown()
        self.tmp.cleanup()

    def mkfile(self, name, size):
        p = os.path.join(self.tmp.name, name)
        with open(p, "wb") as f:
            f.write(os.urandom(size))
        return p

    def conn(self, pw=PW):
        return client.connect("127.0.0.1", self.srv.port, pw)


class TransferTests(Env):
    def test_upload_download_roundtrip(self):
        src = self.mkfile("a.bin", 300_000)
        s, ch = self.conn()
        client.upload(ch, src, show_progress=False)
        out = os.path.join(self.tmp.name, "dl")
        got = client.download(ch, "a.bin", out, show_progress=False)
        s.close()
        self.assertEqual(file_sha256(src), file_sha256(got))

    def test_empty_file(self):
        src = self.mkfile("empty.bin", 0)
        s, ch = self.conn()
        client.upload(ch, src, show_progress=False)
        self.assertIn("empty.bin", [f["name"] for f in client.list_files(ch)])
        s.close()

    def test_resume_upload(self):
        src = self.mkfile("big.bin", 1_000_000)
        s, ch = self.conn()
        with self.assertRaises(client.SimulatedDrop):
            client.upload(ch, src, show_progress=False, fail_after=300_000)
        s.close()
        time.sleep(0.5)
        s, ch = self.conn()
        client.upload(ch, src, show_progress=False)   # resumes
        s.close()
        self.assertEqual(file_sha256(src), file_sha256(os.path.join(self.store, "big.bin")))

    def test_resume_download(self):
        src = self.mkfile("d.bin", 500_000)
        s, ch = self.conn(); client.upload(ch, src, show_progress=False); s.close()
        out = os.path.join(self.tmp.name, "dl"); os.makedirs(out)
        final = os.path.join(out, "d.bin")
        with open(src, "rb") as f, open(final + ".part", "wb") as g:   # fake interrupted download
            g.write(f.read(200_000))
        with open(final + ".part.meta", "w") as m:
            json.dump({"sha256": file_sha256(src), "size": 500_000}, m)
        s, ch = self.conn()
        client.download(ch, "d.bin", out, show_progress=False)
        s.close()
        self.assertEqual(file_sha256(src), file_sha256(final))

    def test_many_clients_parallel(self):
        errors = []

        def work(i):
            try:
                src = self.mkfile(f"f{i}.bin", 200_000 + i * 1000)
                s, ch = self.conn()
                client.upload(ch, src, show_progress=False)
                got = client.download(ch, f"f{i}.bin", os.path.join(self.tmp.name, f"d{i}"), False)
                s.close()
                assert file_sha256(src) == file_sha256(got)
            except Exception as e:
                errors.append(e)
        ts = [threading.Thread(target=work, args=(i,)) for i in range(8)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(errors, [])

    def test_path_traversal_blocked(self):
        s, ch = self.conn()
        ch.send_json({"cmd": "download", "name": "../../etc/passwd", "offset": 0})
        self.assertFalse(ch.recv_json()["ok"])
        s.close()


class SecurityTests(Env):
    def test_wrong_password_rejected(self):
        with self.assertRaises(SecurityError):
            self.conn("wrong-password")

    def _pair(self):
        a, b = socket.socketpair()
        res = {}
        t = threading.Thread(target=lambda: res.update(s=server_handshake(b, PW)))
        t.start()
        c = client_handshake(a, PW)
        t.join()
        return a, b, c, res["s"]

    def test_tampered_frame_detected(self):
        a, b, c, s = self._pair()
        c.send(b"D", b"hello world")
        raw = b.recv(4096)
        bad = bytearray(raw); bad[10] ^= 0x01            # flip one ciphertext bit
        x, y = socket.socketpair()
        s.sock = y; x.sendall(bytes(bad))
        with self.assertRaises(SecurityError):
            s.recv()

    def test_replay_detected(self):
        a, b, c, s = self._pair()
        c.send(b"D", b"pay 100")
        raw = b.recv(4096)
        x, y = socket.socketpair()
        s.sock = y
        x.sendall(raw); self.assertEqual(s.recv()[1], b"pay 100")
        x.sendall(raw)                                    # replay same frame
        with self.assertRaises(SecurityError):
            s.recv()

    def test_ciphertext_is_not_plaintext(self):
        a, b, c, s = self._pair()
        c.send(b"D", b"SECRET-PLAINTEXT-MARKER")
        self.assertNotIn(b"SECRET-PLAINTEXT-MARKER", b.recv(4096))


if __name__ == "__main__":
    unittest.main()
