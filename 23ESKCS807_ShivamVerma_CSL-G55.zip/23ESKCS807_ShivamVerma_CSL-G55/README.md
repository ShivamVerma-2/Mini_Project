# Multi-client Encrypted File Transfer with HMAC
**Syllabus Project – Secure LAN File Transfer**

| | |
|---|---|
| Student | Shivam Verma |
| Roll No | 23ESKCS807 |
| Project Code | CSL-G55 |
| Course | Cyber Security Lab |

A threaded client/server application that transfers files over a LAN with
**AES-256 encryption**, **HMAC-SHA256 integrity checking**, a **progress bar** and
**resume support** for interrupted transfers. Written in Python 3 (standard library + `cryptography`).

---
## 1. Features
| Requirement | Implementation |
|---|---|
| Threaded server for many clients | `server.py` – one thread per client, bounded by `--max-clients`; per-file locks stop two clients writing the same file |
| AES encryption | AES-256-CTR, fresh random IV for every frame (`common.py`) |
| HMAC integrity check | HMAC-SHA256 on every frame (Encrypt-then-MAC, verified *before* decryption) + SHA-256 of the whole file at the end |
| Progress bar | `Progress` class: percentage, bytes, speed, ETA |
| Resume support | Server keeps `.partial/<file>.part`; client re-run continues from the saved offset (upload and download) |

Extra security: password-based mutual authentication, replay/reorder protection (sequence numbers),
path-traversal protection, max file size, idle time-out, constant-time tag comparison.

## 2. Project structure
```
common.py        Secure channel (AES+HMAC), handshake, progress bar, helpers
server.py        Multi-threaded server
client.py        Command line client (list / upload / download)
tests/test_all.py  10 automated tests (functional + security)
requirements.txt
README.md
```

## 3. Installation
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt   # installs 'cryptography'
```
Python 3.8+ required.

## 4. Usage
**Start the server** (machine A):
```bash
python server.py --port 5001 --storage ./server_storage
# prompts for the shared password (or set env FT_PASSWORD / use --password)
```
**Client** (any machine on the LAN; use the server's IP instead of 127.0.0.1):
```bash
python client.py --host 127.0.0.1 --port 5001 list
python client.py --host 127.0.0.1 --port 5001 upload report.pdf
python client.py --host 127.0.0.1 --port 5001 download report.pdf --out ./downloads
```
Run several clients in different terminals at the same time to see the multi-client behaviour.

### Resume demo
```bash
python client.py upload big.bin --fail-after 1500000   # simulates a dropped connection
python client.py upload big.bin                        # prints "Resuming 'big.bin' from ..." and finishes
```
Downloads resume the same way (a `.part` file is kept in the output folder).

### Wrong password / tampering demo
```bash
FT_PASSWORD=wrong python client.py list      # -> [!] authentication failed (wrong password?)
```
Run the automated tests (includes bit-flip tamper test and replay test):
```bash
python -m unittest discover -s tests -v
```

## 5. Protocol & security design
```
Client                                          Server
  |-- client_nonce (16 B) ------------------------>|
  |<-- salt (16 B) + server_nonce (16 B) ----------|
  |  both: master = PBKDF2-HMAC-SHA256(password, salt, 200000)
  |        enc_key = HMAC(master, "enc"|cn|sn)   mac_key = HMAC(master, "mac"|cn|sn)
  |-- HMAC(mac_key,"client-auth"|cn|sn) ---------->|  verify -> else drop
  |<-- HMAC(mac_key,"server-auth"|cn|sn) ----------|  verify
  |========= encrypted frames from here ==========|
Frame = IV(16) | AES-CTR(type(1)+payload) | HMAC-SHA256( dir | seq(8) | IV | ciphertext )
```
* **Confidentiality** – AES-256-CTR; a new IV per frame; a sniffer sees only random bytes.
* **Integrity/authenticity** – any modified byte makes the HMAC fail; the connection is dropped.
* **Replay / reordering** – the sequence number and direction are inside the MAC.
* **Password is never sent** – only HMAC proofs; both sides prove knowledge of the key.
* **End-to-end check** – SHA-256 of the complete file is compared after every upload/download; mismatching files are discarded.
* **Resume safety** – partial files are bound to (SHA-256, size) in a `.meta` file; if the file changed, resume restarts from 0.

Message types: `list`, `upload{name,size,sha256}` → `{offset}` → data frames, `download{name,offset}`, `quit`.

## 6. Limitations / future work
* Shared-password model (no per-user accounts); no TLS certificates / forward secrecy (could add ECDH).
* CTR provides no integrity itself – integrity comes from the HMAC (Encrypt-then-MAC); AES-GCM could replace both.
* Server stores files in a flat folder with no per-user access control.
* Use a strong password; PBKDF2 slows brute force but cannot stop a weak password being guessed offline from captured handshakes.

## 7. Ethical notice
Test only on your own computer / virtual machines. Do not run on the college network or any system you do not own.
